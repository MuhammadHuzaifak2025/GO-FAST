import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Download, Github, Linkedin, Twitter } from "lucide-react";
import Image from "next/image";
import Link from "next/link";

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen bg-white text-[#12b76a]">
      <header className="px-4 lg:px-6 h-16 flex items-center border-b border-[#12b76a]">
        <Link className="flex items-center justify-center" href="#">
          <Image
            src="/logo.png"
            alt="Carpool & Buspool Logo"
            color="black"
            width={120}
            height={120}
            className="rounded-lg"
          />
          {/* <span className="ml-2 text-lg font-bold text-[#12b76a]">Carpool & Buspool</span> */}
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link
            className=" text-lg font-medium hover:text-[#12b76a] transition-colors"
            href="/login"
          >
            Admin Panel
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full pt-12 md:pt-24 lg:pt-32 xl:pt-48 pb-8 md:pb-20 lg:pb-28 xl:pb-44  bg-[#f3f3f398] border rounded-xl">
          <div className="px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none text-black">
                  Welcome to{" "}
                  <span className="text-[#12b76a]">Carpool & Buspool</span>
                </h1>
                <p className="mx-auto max-w-[700px] text-gray-400 md:text-xl">
                  Your go-to solution for convenient and eco-friendly
                  transportation. Download our app and join the community today!
                </p>
              </div>
              <div className="space-x-4">
                <Button
                  asChild
                  className="bg-[#12b76a] hover:bg-[#0e9355] text-white"
                >
                  <Link href="#download">Download APK</Link>
                </Button>
                <Button
                  asChild
                  variant="outline"
                  className="border-[#12b76a] text-[#12b76a] hover:bg-[#12b76a] hover:text-white"
                >
                  <Link href="#developers">Meet Our Developers</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
        <section id="developers" className="w-full mt-10">
          <div className="px-4 md:px-6">
            <div className="flex flex-col items-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl space-y-2">
                  Meet Our Developers
                </h2>
                <p className="mx-auto max-w-[600px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  The talented team behind Carpool & Buspool. Connect with us
                  and learn more about our journey.
                </p>
              </div>
              <div className="flex justify-between w-2/4 pt-6">
                {[
                  { name: "Ilyas Moiz", role: "Frontend Developer" },
                  { name: "Muhammad Huzaifa", role: "Backend Developer" },
                  { name: "Daniyal Saeed Dani", role: "Full Stack" },
                ].map((developer) => (
                  <Card
                    key={developer.name}
                    className="bg-gray-900 border-[#12b76a]"
                  >
                    <CardContent className="p-4 flex flex-col items-center space-y-2 w-48">
                      <Image
                        alt={developer.name}
                        className="rounded-full"
                        height="80"
                        src="/placeholder.svg?height=80&width=80"
                        style={{
                          aspectRatio: "80/80",
                          objectFit: "cover",
                        }}
                        width="80"
                      />
                      <h3 className="font-semibold text-[#12b76a]">
                        {developer.name}
                      </h3>
                      <p className="text-sm text-gray-400">{developer.role}</p>
                      <div className="flex space-x-2">
                        <Link
                          className="text-gray-400 hover:text-[#12b76a]"
                          href="#"
                        >
                          <Github className="h-5 w-5" />
                          <span className="sr-only">GitHub</span>
                        </Link>
                        <Link
                          className="text-gray-400 hover:text-[#12b76a]"
                          href="#"
                        >
                          <Linkedin className="h-5 w-5" />
                          <span className="sr-only">LinkedIn</span>
                        </Link>
                        <Link
                          className="text-gray-400 hover:text-[#12b76a]"
                          href="#"
                        >
                          <Twitter className="h-5 w-5" />
                          <span className="sr-only">Twitter</span>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t border-[#12b76a] mt-12">
        <p className="text-xs text-gray-400">
          © 2024 Carpool & Buspool. All rights reserved.
        </p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6"></nav>
      </footer>
    </div>
  );
}
